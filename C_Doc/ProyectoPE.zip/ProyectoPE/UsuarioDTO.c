//
// Created by Jesus Emmanuel Garcia on 2/17/25.
//

#include "UsuarioDTO.h"

#include <curses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LogicaNegocio.h"
#include "UserInterface.h"

#include "SystemLogs.h"

#include "Util.h"
//Variable encapsulada -> Private
int id_UsuarioGlobal = 0;
int id_piezaGlobal = 0;
int id_unicoLogs = 0;
//int id_Pieza = 0;
// Declaración global de array's
ArrayUsuarios arrayUsuarios = {0};
ArrayTickets arrayTickets = {0};  // ← variable global
ArrayList array_list;
ArrayPiezas arrayMotoresPrecargados = {0};
ArrayPiezas arrayMotoresUsuarios = {0};
ArrayPiezas arrayPiezas = {0};
ArrayPiezasAlmacen arrayPiezasAlmacen = {0};
Almacen almacenBaseDatos = {0};
ArrayLogs arrayLogs = {0};


//Funciones Importantes para la ejecucion detodo el programa y evitar la reutilizacion de codigo

Usuario inicializarUsuario(const int id_usuario, char* folio, const char* nombreUsuario, const char* apellido,
                          long long celular, const char* email, const char* contacto) {
    Usuario usr = {0};
    usr.id_usuario = id_usuario;
    asignString(usr.folio, folio, sizeof(usr.folio));
    asignString(usr.nombreUsuario, nombreUsuario, sizeof(usr.nombreUsuario));
    asignString(usr.apellido, apellido, sizeof(usr.apellido));
    usr.celular = celular;
    asignString(usr.email, email, sizeof(usr.email));
    asignString(usr.contacto, contacto, sizeof(usr.contacto));

    usr.motor = NULL;
    usr.activo = 1;
    setIdUsuarioLogico(getIdUsuarioLogico() + 1);

    agregarSystemLog(id_usuario, "Inicializar Usuario", "Usuario", folio, INFO, 1,
                     "UsuarioDTO.c", "inicializarUsuario", HTTP_CREATED);

    return usr;
}

/**
 * Solo se pasaran commo variables estaticas
 * Las variables que no pertenecen unicamente del motor
 * @param params
 * @param paramsmotor
 * @param id_usuario,
 * @param id_pieza,
 * @param numero_serie
 * @param tipoDePieza
 * @param tipoPieza -> MONOBLOCK = 0, CULATA = 1.
 *
 */
Motor* inicializarMotor(Paramsmotor params, const int id_usuario, const int id_pieza, void* tipoDePieza, const int tipoPieza) {
    Motor* pz = (Motor*)malloc(sizeof(Motor));
    if (pz == NULL) {
        agregarSystemLog(id_usuario, "Inicializar Motor", "Motor", params.numeroSerie, ERROR, 0,
                         "UsuarioDTO.c", "inicializarMotor", HTTP_INTERNAL_SERVER_ERROR);
        perror("Error al asignar memoria para Motor");
        exit(EXIT_FAILURE);
    }

    pz->id_usuario = id_usuario;
    pz->id_pieza = id_pieza;
    pz->tipoCombustible = params.tipoCombustible;
    asignString(pz->material, params.material, sizeof(pz->material));
    pz->modelo = params.modelo;
    pz->fabricante = params.fabricante;
    pz->carroAsociado = params.carroAsociado;
    pz->numeroSerie = params.numeroSerie;
    pz->anno = params.anno;
    pz->cilindrada = params.cilindrada;
    pz->compresionOriginal = params.compresionOriginal;
    pz->medidaOriginal = params.medidaOriginal;
    pz->medidaActual = params.medidaActual;
    pz->culata = NULL;
    pz->monoblock = NULL;

    agregarSystemLog(id_usuario, "Inicializar Motor", "Motor", params.numeroSerie, INFO, 1,
                     "UsuarioDTO.c", "inicializarMotor", HTTP_CREATED);

    return pz;
}

Culata* inicializarCulata(int id_pieza, int numValvulas, double presionPrueba, int fisuras,
                          float alturaOriginal, float alturaActual, float alturaMinima, int id_usuario, int estadoPieza) {
    Culata* culata = malloc(sizeof(Culata));
    if (culata == NULL) {
        agregarSystemLog(id_usuario, "Inicializar Culata", "Culata", "UNKNOWN", ERROR, 0,
                         "UsuarioDTO.c", "inicializarCulata", HTTP_INTERNAL_SERVER_ERROR);
        perror("Error al asignar memoria para Culata");
        exit(EXIT_FAILURE);
    }

    culata->id_usuario = id_usuario;
    culata->id_pieza = id_pieza;
    culata->numValvulas = numValvulas;
    culata->presionPrueba = presionPrueba;
    culata->tieneFisuras = fisuras;
    culata->alturaOriginal = alturaOriginal;
    culata->alturaActual = alturaActual;
    culata->alturaMinima = alturaMinima;
    culata->estadoTemporalPieza = -1;
    culata->operacionesMotor = estadoPieza;
    id_piezaGlobal++;

    char id_objeto[50];
    snprintf(id_objeto, sizeof(id_objeto), "CULATA_%d", id_pieza); // Generar ID único para el log

    agregarSystemLog(id_usuario, "Inicializar Culata", "Culata", id_objeto, INFO, 1,
                     "UsuarioDTO.c", "inicializarCulata", HTTP_CREATED);

    return culata;
}

//Getters y setters
void setIdUsuarioLogico(const int nuevoId){
    id_UsuarioGlobal = nuevoId;
};
int getIdUsuarioLogico(){
    return id_UsuarioGlobal;
};
void setIdLog(const int id) {
    id_unicoLogs = id;
}
int getIdLog() {
    return id_unicoLogs;
}

//Funcion para clonar el contenido de una variable a otra nueva variable
//-> Esto no pasaria con POO ya que cada nuevo objeto es una nueva direccion en memoria, y si quiero asignar, se asignan los valores de esa direccion PROPIA
Motor* clonarMotor(Motor* original, int nuevoIdUsuario) {
    if (original == NULL) {
        agregarSystemLog(nuevoIdUsuario, "Clonar Motor", "Motor", "NULL", ERROR, 0,
                         "UsuarioDTO.c", "clonarMotor", HTTP_UNPROCESSABLE_ENTITY);
        return NULL;
    }

    Motor* copia = malloc(sizeof(Motor));
    if (!copia) {
        agregarSystemLog(nuevoIdUsuario, "Clonar Motor", "Motor", "NULL", ERROR, 0,
                         "UsuarioDTO.c", "clonarMotor", HTTP_INTERNAL_SERVER_ERROR);
        return NULL;
    }

    *copia = *original;
    copia->modelo = strdup(original->modelo);
    copia->fabricante = strdup(original->fabricante);
    copia->carroAsociado = strdup(original->carroAsociado);
    asignString(copia->material, original->material, sizeof(copia->material));
    copia->numeroSerie = strdup(original->numeroSerie);
    copia->id_usuario = nuevoIdUsuario;
    copia->culata = NULL;

    agregarSystemLog(nuevoIdUsuario, "Clonar Motor", "Motor", copia->numeroSerie, INFO, 1,
                     "UsuarioDTO.c", "clonarMotor", HTTP_CREATED);

    return copia;
}